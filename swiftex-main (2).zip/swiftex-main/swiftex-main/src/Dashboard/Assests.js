import React from "react";
import {
  StyleSheet,
  Text,
  View,
  Button,
  TextInput,
  FlatList,
  TouchableOpacity,
  Alert,
} from "react-native";

const Assests = () => {
  return (
    <View
      style={{
        display: "flex",
        backgroundColor: "#131E3A",
        height: 700,
        position: "absolute",
        width: 420,
      }}
    >
      <Text>Assests</Text>
    </View>
  );
};

export default Assests;
